public interface Visitor {
    public void visit(FileSystem fileSystem);
}
